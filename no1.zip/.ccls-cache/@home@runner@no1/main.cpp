#include <iostream>

using namespace std;

int main() {

  string nama1, nama2, nama3;
  int lollipop1, lollipop2, lollipop3;
  int max;
  int selisih1;
  int selisih2;

  cout << "Program Hilman Fiqri ";
  cout << endl;
  cout << "NRP:15-2019-109 ";
  cout << endl;
  cout << "Nama anak 1 = ";
  cin >> nama1;
  cout << "Jumlah Permen 1 = ";
  cin >> lollipop1;
  cout << "Nama anak 2 = ";
  cin >> nama2;
  cout << "Jumlah Permen 2 = ";
  cin >> lollipop2;
  cout << "Nama anak 3 = ";
  cin >> nama3;
  cout << "Jumlah Permen 3 = ";
  cin >> lollipop3;
  cout << endl;
  if (lollipop1 > lollipop2 && lollipop1 > lollipop3) {
    selisih1 = lollipop1 - lollipop2;
    selisih2 = lollipop1 - lollipop3;
    cout << "Permen Anak Bernama " << nama1 << " Paling Banyak "
         << "Dengan Jumlah " << lollipop1
         << " Yang Berselisih dengan lollipop lain " << selisih1 << " dan "
         << selisih2;
  } else if (lollipop2 > lollipop1 && lollipop2 > lollipop3) {
    selisih1 = lollipop2 - lollipop1;
    selisih2 = lollipop2 - lollipop3;
    cout << "Permen Anak Bernama " << nama2 << " Paling Banyak "
         << "Dengan Jumlah " << lollipop2
         << " Yang Berselisih dengan lollipop lain " << selisih1 << " dan "
         << selisih2;
  } else if (lollipop3 > lollipop2 && lollipop3 > lollipop1) {
    selisih1 = lollipop3 - lollipop1;
    selisih2 = lollipop3 - lollipop2;
    cout << "Permen Anak Bernama " << nama3 << " Paling Banyak "
         << "Dengan Jumlah " << lollipop3
         << " Yang Berselisih dengan lollipop lain " << selisih1 << " dan "
         << selisih2;
  } else {
    cout << "Jumlahnya Sama Banyak Dan Tidak Ada Selisihnya ";
  }
}