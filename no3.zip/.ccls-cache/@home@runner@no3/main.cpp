#include <iostream>
#include <string>

using namespace std;

int main() {
  int totalbayar;
  float diskon;
  string a;
  int jambelanja;
  int hargaawal;

  cout << "Program Hilman Fiqri ";
  cout << endl;
  cout << "NRP: 15-2019-109";
  cout << endl;
  cout << "Total Belanja: ";
  cin >> hargaawal;
  cout << "Masukan Jam Belanja : ";
  cin >> jambelanja;
  cout << endl;
  if (jambelanja > 1300 && jambelanja < 1400) {
    diskon = 0.2;
    totalbayar = (hargaawal - (hargaawal * diskon));
    cout << "Selamat anda mendapatkan diskon "
         << "20% "
         << "Menjadi " << totalbayar << endl;
  } else {
    totalbayar = hargaawal;
    cout << "Maaf anda tidak mendpatkan diskon "
         << "Total Belanja Anda = " << hargaawal;
  }
}