#include <iostream>
#include <stdlib.h>

using namespace std;

int main() {
  int i;
  string pin_input;
  
  cout << "Program Hilman Fiqri ";
  cout << endl;
  cout << "NRP: 15-2019-109";
  cout << endl;
  cout << "BANK LAS VEGAS " << endl;
  string pin = "56843";
  string login = "block";
  i = 1;
  cout << "MOHON MASUKAN PIN ANDA";
  cout << endl;
  do {
    cout << "Pin = ";
    cin >> pin_input;
    if (pin_input == pin) {
      cout << "| Silahkan Mengambil Uang/ Berhasil |" << endl;
      i = 4;
      login = "berhasil";
    } else {
      cout << "Pin Salah! (" << i << "x)" << endl;
      i = i + 1;
      cout << endl;
    }
  } while (i <= 3);
  if (login != "berhasil") {
    cout << "Anda telah 3x salah Pin.\n";
    cout << "Kartu Anda Telah Terblokir\n";
    cout << "Mohon Menghubungi Bank Terdekat , Terimakasih\n";
  }
  return 0;

  }