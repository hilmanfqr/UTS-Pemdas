#include <iostream>
#include <stdlib.h>
#include <string>

using namespace std;

int main() {
  string nama1, nama2, nama3;
  int lollipop1, lollipop2, lollipop3;
  int max;
  int selisih1;
  int selisih2;
  int i;
  string pin_input;
  int totalbayar;
  float diskon;
  string a;
  int jambelanja;
  int hargaawal;
  int soal;

  cout << "pilih soal nomer 1/3 :";
  cin >> soal;

  if (soal == 1) {
    cout << "Nama anak 1 = ";
    cin >> nama1;
    cout << "Jumlah Permen 1 = ";
    cin >> lollipop1;
    cout << "Nama anak 2 = ";
    cin >> nama2;
    cout << "Jumlah Permen 2 = ";
    cin >> lollipop2;
    cout << "Nama anak 3 = ";
    cin >> nama3;
    cout << "Jumlah Permen 3 = ";
    cin >> lollipop3;
    cout << endl;
    if (lollipop1 > lollipop2 && lollipop1 > lollipop3) {
      selisih1 = lollipop1 - lollipop2;
      selisih2 = lollipop1 - lollipop3;
      cout << "Permen Anak Bernama " << nama1 << " Paling Banyak "
           << "Dengan Jumlah " << lollipop1
           << " Yang Berselisih dengan lollipop lain " << selisih1 << " dan "
           << selisih2;
    } else if (lollipop2 > lollipop1 && lollipop2 > lollipop3) {
      selisih1 = lollipop2 - lollipop1;
      selisih2 = lollipop2 - lollipop3;
      cout << "Permen Anak Bernama " << nama2 << " Paling Banyak "
           << "Dengan Jumlah " << lollipop2
           << " Yang Berselisih dengan lollipop lain " << selisih1 << " dan "
           << selisih2;
    } else if (lollipop3 > lollipop2 && lollipop3 > lollipop1) {
      selisih1 = lollipop3 - lollipop1;
      selisih2 = lollipop3 - lollipop2;
      cout << "Permen Anak Bernama " << nama3 << " Paling Banyak "
           << "Dengan Jumlah " << lollipop3
           << " Yang Berselisih dengan lollipop lain " << selisih1 << " dan "
           << selisih2;
    } else {
      cout << "Jumlahnya Sama Banyak Dan Tidak Ada Selisihnya ";
    }
  } else if (soal == 2) {
    cout << "Ala Ala Atm " << endl;
    string pin = "56843";
    string login = "block";
    i = 1;
    cout << "SELAMAT DATANG DI ATM MOHON MASUKAN PIN ANDA";
    cout << endl;
    do {
      cout << "Pin = ";
      cin >> pin_input;
      if (pin_input == pin) {
        cout << "| Silahkan Mengambil Uang/ Berhasil |" << endl;
        i = 4;
        login = "berhasil";
      } else {
        cout << "Pin Salah! (" << i << "x)" << endl;
        i = i + 1;
        cout << endl;
      }
    } while (i <= 3);
    if (login != "berhasil") {
      cout << "Anda telah 3x salah Pin.\n";
      cout << "Kartu Anda Telah Terblokir\n";
      cout << "Mohon Menghubungi Bank Terdekat , Terimakasih\n";
    }
    return 0;
  } else if (soal == 3) {
    cout << "Total Belanja: ";
    cin >> hargaawal;
    cout << "Masukan Jam Belanja : ";
    cin >> jambelanja;
    cout << endl;
    if (jambelanja > 1300 && jambelanja < 1400) {
      diskon = 0.2;
      totalbayar = (hargaawal - (hargaawal * diskon));
      cout << "Selamat anda mendapatkan diskon "
           << "20% "
           << "Menjadi " << totalbayar << endl;
    } else {
      totalbayar = hargaawal;
      cout << "Maaf anda tidak mendpatkan diskon "
           << "Total Belanja Anda = " << hargaawal;
    }
  }
}